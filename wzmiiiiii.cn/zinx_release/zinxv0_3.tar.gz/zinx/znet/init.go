package znet

import (
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"gopkg.in/natefinch/lumberjack.v2"
	"os"
)

var sugaredLogger *zap.SugaredLogger

func init() {
	initLogger()
}

// 初始化zap logger
func initLogger() {
	encoderConfig := zap.NewProductionEncoderConfig()
	encoderConfig.EncodeTime = zapcore.ISO8601TimeEncoder
	encoderConfig.EncodeLevel = zapcore.CapitalLevelEncoder

	encoder := zapcore.NewConsoleEncoder(encoderConfig)

	writerSyncer1 := zapcore.AddSync(os.Stderr)

	lumberjackLogger := &lumberjack.Logger{
		Filename:   "./log/logtest.log",
		MaxSize:    5,
		MaxAge:     1,
		MaxBackups: 5,
		Compress:   false,
	}

	writerSyncer2 := zapcore.AddSync(lumberjackLogger)

	writerSyncer := zapcore.NewMultiWriteSyncer(writerSyncer1, writerSyncer2)

	core := zapcore.NewCore(encoder, writerSyncer, zap.InfoLevel)
	logger := zap.New(core, zap.AddCaller(), zap.AddCallerSkip(0))
	sugaredLogger = logger.Sugar()
}
