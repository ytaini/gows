package zlog

func init() {
	initLogger()
}
