package znet

func init() {
	initLogger()
}
