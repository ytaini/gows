package znet

import (
	"io"
	"net"
	"wzmiiiiii.cn/zinx/utils"
	"wzmiiiiii.cn/zinx/ziface"
)

// Connection IConnection实现类
// 连接模块
type Connection struct {
	// 当前连接的socket TCP套接字
	Conn *net.TCPConn
	// 连接的id
	ConnID uint32
	// 当前的连接状态
	isClosed bool
	// 告知当前连接已经退出的channel
	ExitChan chan struct{}
	// 该链接处理的方法Router
	Router ziface.IRouter
}

// NewConnection 初始化链接模块的方法
func NewConnection(conn *net.TCPConn, connID uint32, router ziface.IRouter) *Connection {
	con := &Connection{
		Conn:     conn,
		ConnID:   connID,
		Router:   router,
		isClosed: false,
		ExitChan: make(chan struct{}, 1),
	}
	return con
}

func (c *Connection) StartReader() {
	sugaredLogger.Infoln("Reader Goroutine is running...")

	defer sugaredLogger.Infof("ConnID: %d, Reader is exit,remote addr is %v", c.ConnID, c.RemoteAddr())
	defer func(c *Connection) {
		err := c.Stop()
		if err != nil {
			sugaredLogger.Errorf("Conn stop err: %v", err)
		}
	}(c)

	for {
		buf := make([]byte, utils.GlobalObject.MaxPackageSize)
		cnt, err := c.Conn.Read(buf)
		if err != nil {
			if err != io.EOF {
				sugaredLogger.Errorf("recv data err: %v", err)
			}
			break
		}

		sugaredLogger.Infof("Server recv client data: %s,cnt:%d", string(buf[:cnt]), cnt)

		// 得到当前conn的Request请求数据对象
		req := &Request{
			data: buf,
			conn: c,
		}

		// 执行注册的路由方法
		go func(req ziface.IRequest) {
			c.Router.PreHandle(req)
			c.Router.Handle(req)
			c.Router.PostHandle(req)
		}(req)

	}
}

func (c *Connection) Start() error {
	sugaredLogger.Infof("Conn: %d Starting ...", c.ConnID)
	// 启动从当前连接的读数据的业务.
	go c.StartReader()
	return nil
}

func (c *Connection) Stop() error {
	// 如果当前连接已经关闭
	if c.isClosed {
		return nil
	}
	sugaredLogger.Infof("Conn: %d is Stopped ...", c.ConnID)
	c.isClosed = true
	err := c.Conn.Close()
	close(c.ExitChan)
	return err
}

func (c *Connection) GetTCPConnection() *net.TCPConn {
	return c.Conn
}

func (c *Connection) GetConnID() uint32 {
	return c.ConnID
}

func (c *Connection) RemoteAddr() net.Addr {
	return c.Conn.RemoteAddr()
}

func (c *Connection) Write(bytes []byte) (int, error) {
	return c.Conn.Write(bytes)
}
